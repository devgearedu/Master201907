# 미션1 - 델파이문법

DelphiStudyGroup.groupproj 프로젝트 그룹을 열고, 각 과제별 소스코드를 완성하세요.
소스코드에는 TODO 주석이 포함되어 있습니다. TODO 주석의 순서에 맞게 코드를 작성하세요.

작성 후 Pull Request를 통해 제출하기바랍니다.
